/*!
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
// some data used in the examples
Ext.namespace('Ext.exampledata');

Ext.exampledata.dutch_provinces = [
	['Drenthe'],
	['Flevoland'],
	['Friesland'],
	['Gelderland'],
	['Groningen'],
	['Limburg'],
	['Noord-Brabant'],
	['Noord-Holland'],
	['Overijsel'],
	['Utrecht'],
	['Zeeland'],
	['Zuid-Holland']
    ];
